package com.example.raulp.loginsign_up.AccountActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;

import android.view.View;
import android.view.View.OnClickListener;

import com.example.raulp.loginsign_up.R;

public class Main2Activity extends AppCompatActivity {
    ImageButton imageButton_MatchMaker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        addListenerOnButton();
    }
    public void addListenerOnButton() {
        imageButton_MatchMaker = (ImageButton) findViewById(R.id.imageButton2);
        imageButton_MatchMaker.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(Main2Activity.this, MatchMakerActivity.class);
                startActivity(intent);

            }
        });

    }
}
