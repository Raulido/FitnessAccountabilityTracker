package com.example.raulp.loginsign_up.AccountActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.view.SurfaceHolder.Callback;


public class EditProfileActivity extends AppCompatActivity {
    public boolean userAlreadyExists = true;
    protected void onCreate(Bundle savedInstanceState) {
        //read database

        ////// code for reading from database

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                String name = dataSnapshot.child("users").child(userId).child("username").getValue(String.class);  // Reading from users/UserID/username
                String bio = dataSnapshot.child("users").child(userId).child("bio").getValue(String.class);
                TextInputEditText nameInput = (TextInputEditText) findViewById(R.id.edit_profile_edit_name);
                nameInput.setText(name);
                TextInputEditText bioInput = (TextInputEditText) findViewById(R.id.edit_profile_edit_bio);
                bioInput.setText(bio);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);
        ////// end of code for reading from database

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editprofile);
        addListenerOnButton();





    }
    public void addListenerOnButton() {
        Button save_changes = (Button) findViewById(R.id.edit_profile_save_changes);
        save_changes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                TextInputEditText nameInput = (TextInputEditText) findViewById(R.id.edit_profile_edit_name);
                final String newname = nameInput.getText().toString();

                String username_error = "Username must start with a letter and cannot contain spaces and cannot be newuser";

                if (Character.isDigit(newname.charAt(0)) || newname.contains(" ") || newname.equals("newuser")){
                    TextView username_error_textview = (TextView) findViewById(R.id.edit_profile_username_error_textview);
                    username_error_textview.setText(username_error);
                    return;
                }

                DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                ValueEventListener changeListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String listOfUsersIds = dataSnapshot.child("listOfUsers").getValue(String.class).toString();
                        String [] arrayUserIds = listOfUsersIds.split(" ");
                        String userNames ="";
                        for (String itor: arrayUserIds){
                            userNames= userNames + " " + dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString();
                        }
                        System.out.println(listOfUsersIds);
                        System.out.println(arrayUserIds);
                        System.out.println(userNames);
                        if (userNames.contains(newname)) {
                            userAlreadyExists = true;
                            System.out.println("EXITS ALREADY");
                        } else {
                            userAlreadyExists = false;
                        }

                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {}
                };
                database.addListenerForSingleValueEvent(changeListener);
                if (userAlreadyExists) {
                    username_error = "Username already exists";

                    TextView username_error_textview = (TextView) findViewById(R.id.edit_profile_username_error_textview);
                    username_error_textview.setText(username_error);

                    return;// no further action user exists
                }
                else {}
                TextInputEditText bioInput = (TextInputEditText) findViewById(R.id.edit_profile_edit_bio);
                String bio = bioInput.getText().toString();
                String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                database = FirebaseDatabase.getInstance().getReference();
                database.child("users").child(userId).child("username").setValue(newname);
                database.child("users").child(userId).child("bio").setValue(bio);
                Intent intent = new Intent(EditProfileActivity.this, HomePageActivity.class);
                startActivity(intent);
            }
        });
        Button edit_profile = (Button) findViewById(R.id.edit_profile_discard_changes);
        edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(EditProfileActivity.this, HomePageActivity.class);
                startActivity(intent);
            }
        });
        ImageButton home = (ImageButton) findViewById(R.id.edit_profile_home_button);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(EditProfileActivity.this, HomePageActivity.class);
                startActivity(intent);
            }
        });
    }
}
