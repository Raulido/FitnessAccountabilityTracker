package com.example.raulp.loginsign_up.AccountActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Button;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FriendsPageActivity extends AppCompatActivity {
    public boolean usernameIsCorrect = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friendspage);
        addListenerOnButton();
    }


    public void addListenerOnButton() {
        final Button addFriendButton = (Button) findViewById(R.id.friends_page_addfriend_button);
        addFriendButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                TextInputEditText addFriendEditText = (TextInputEditText) findViewById(R.id.friends_page_addfriendtextInput);
                String friendToBeAdded = addFriendButton.getText().toString();
                if(UserExits(friendToBeAdded)){
                    TextView error = (TextView) findViewById(R.id.friends_page_error_textview);
                    error.setText("Error user does not exist");
                }
                if(AlreadyFriend(friendToBeAdded)){
                    TextView error = (TextView) findViewById(R.id.friends_page_error_textview);
                    error.setText("Error user is already friend");
                }


            }
        });
    }
    public boolean UserExits(String username){

        return true;
    }
    public boolean AlreadyFriend(String username){
        return true;
    }
}