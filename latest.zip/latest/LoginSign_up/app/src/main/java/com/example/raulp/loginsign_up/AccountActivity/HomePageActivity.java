package com.example.raulp.loginsign_up.AccountActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.database.*;
import com.google.firebase.auth.*;

public class HomePageActivity extends AppCompatActivity {
    public boolean usernameIsCorrect = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {



        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                String name = dataSnapshot.child("users").child(userId).child("username").getValue(String.class);  // Reading from users/UserID/username
                // Do stuff with the stuff we read
                TextView welcomeUserTextView = (TextView)findViewById(R.id.textView);
                welcomeUserTextView.setText("Welcome "+ name + "!");

                if (name.equals("newuser")){
                    TextView change_usr_message = (TextView) findViewById(R.id.home_page_must_change_user_textview);
                    change_usr_message.setText("You must go to edit profile to change your username");
                    usernameIsCorrect=false;
                } else{
                    TextView change_usr_message = (TextView) findViewById(R.id.home_page_must_change_user_textview);
                    change_usr_message.setText("");
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        addListenerOnButton();
    }

    public void addListenerOnButton() {
        ImageButton matchMakerButton = (ImageButton) findViewById(R.id.imageButton2);
        matchMakerButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                final DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                ValueEventListener changeListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                        String name = dataSnapshot.child("users").child(userId).child("username").getValue(String.class);  // Reading from users/UserID/username
                        checkName(name);
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) { }

                };

                database.addValueEventListener(changeListener);

                if (usernameIsCorrect){
                    Intent intent = new Intent(HomePageActivity.this, MatchMakerActivity.class);
                    startActivity(intent);
                } else {
                    TextView change_usr_message = (TextView) findViewById(R.id.home_page_must_change_user_textview);
                    change_usr_message.setText("You must change your username to continue");
                    usernameIsCorrect=false;
                }

            }
        });
        ImageButton edit_profile = (ImageButton) findViewById(R.id.edit_profile_button);
        edit_profile.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {

                    Intent intent = new Intent(HomePageActivity.this, EditProfileActivity.class);
                    startActivity(intent);
            }
        });
        ImageButton view_profile = (ImageButton) findViewById(R.id.home_page_view_profile_button);
        view_profile.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                ValueEventListener changeListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                        String name = dataSnapshot.child("users").child(userId).child("username").getValue(String.class);  // Reading from users/UserID/username
                        checkName(name);

                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {}
                };

                database.addValueEventListener(changeListener);

                if (usernameIsCorrect){
                    Intent intent = new Intent(HomePageActivity.this, ViewProfileActivity.class);
                    startActivity(intent);
                } else {
                    TextView change_usr_message = (TextView) findViewById(R.id.home_page_must_change_user_textview);
                    change_usr_message.setText("You must change your username to continue");
                }
            }
        });
        ImageButton friendsPageButton = (ImageButton) findViewById(R.id.home_page_friendspage_button);
        friendsPageButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                ValueEventListener changeListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                        String name = dataSnapshot.child("users").child(userId).child("username").getValue(String.class);  // Reading from users/UserID/username
                        checkName(name);
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) { }
                };

                database.addValueEventListener(changeListener);

                if (usernameIsCorrect){
                    Intent intent = new Intent(HomePageActivity.this, FriendsPageActivity.class);
                    startActivity(intent);
                } else {
                    TextView change_usr_message = (TextView) findViewById(R.id.home_page_must_change_user_textview);
                    change_usr_message.setText("You must change your username to continue");
                    usernameIsCorrect=false;
                }

            }
        });
    }
    public void checkName(String name){
        if (name.equals("newuser")){
            usernameIsCorrect = false;
        } else{
            usernameIsCorrect =true;
        }
    }
    }


