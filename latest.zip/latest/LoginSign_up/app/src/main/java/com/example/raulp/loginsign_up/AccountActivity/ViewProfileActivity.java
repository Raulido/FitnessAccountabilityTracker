package com.example.raulp.loginsign_up.AccountActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ViewProfileActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        final String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("users").child(userId).child("username").getValue(String.class);  // Reading from users/UserID/username
                String bio = dataSnapshot.child("users").child(userId).child("bio").getValue(String.class);
                String rank = dataSnapshot.child("users").child(userId).child("rank").getValue(int.class).toString();
                String experience = dataSnapshot.child("users").child(userId).child("experience").getValue(int.class).toString();
                String last_workout = dataSnapshot.child("users").child(userId).child("last_workout").getValue(String.class);
                String matches_won = dataSnapshot.child("users").child(userId).child("matches_won").getValue(int.class).toString();
                TextView nameText = (TextView) findViewById(R.id.view_profile_username_text);
                nameText.setText(name);
                TextView biotext = (TextView) findViewById(R.id.view_profile_bio_textbox);
                biotext.setText(bio);
                TextView ranktext = (TextView) findViewById(R.id.view_profile_rank_text);
                ranktext.setText(rank);
                TextView last_workout_text = (TextView) findViewById(R.id.view_profile_rank_last_workout);
                last_workout_text.setText(last_workout);
                TextView matches_won_text = (TextView) findViewById(R.id.view_profile_matches_won);
                matches_won_text.setText(matches_won);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);
        ////// end of code for reading from database

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewprofile);
        addListenerOnButton();




    }
    public void addListenerOnButton() {
        ImageButton home = (ImageButton) findViewById(R.id.view_profile_home_button);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(ViewProfileActivity.this, HomePageActivity.class);
                startActivity(intent);
            }
        });

    }

}
