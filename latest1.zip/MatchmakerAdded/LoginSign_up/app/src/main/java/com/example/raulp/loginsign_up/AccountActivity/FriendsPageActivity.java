package com.example.raulp.loginsign_up.AccountActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Button;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FriendsPageActivity extends AppCompatActivity {
    public boolean userIsAlreadyFriend = false;
    public boolean userDoesNotExist = true;
    public String currentUsername="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String currentUserId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                currentUsername = dataSnapshot.child("users").child(currentUserId).child("username").getValue(String.class).toString();
                String listOfFriends = dataSnapshot.child("users").child(currentUserId).child("friends").getValue(String.class).toString();
                String[] arrayOfFriendsIds = listOfFriends.split(" ");
                System.out.println("array:");

                System.out.println("list:");

                System.out.println(listOfFriends);

                String userNames ="";
                if (listOfFriends.length()>0) {
                    for (String itor : arrayOfFriendsIds) {
                        userNames = userNames + " \n\n" + dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString();
                        System.out.println("name: ");
                        System.out.println(itor);
                    }
                }
                TextView friends = (TextView) findViewById(R.id.friends_page_list_of_friends);
                friends.setText(userNames);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);
        setContentView(R.layout.activity_friendspage);
        addListenerOnButton();
    }


    public void addListenerOnButton() {
        final Button addFriendButton = (Button) findViewById(R.id.friends_page_addfriend_button);
        addFriendButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {

                TextInputEditText addFriendEditText = (TextInputEditText) findViewById(R.id.friends_page_addfriendtextInput);
                String friendToBeAdded = addFriendEditText.getText().toString();
                checkIfAlreadyFriend(friendToBeAdded);
                if (friendToBeAdded.equals(currentUsername)){
                    TextView error = (TextView) findViewById(R.id.friends_page_error_textview);
                    error.setText("Error cannot add yourself");
                    userIsAlreadyFriend = false;
                    userDoesNotExist = true;
                    return;
                }
                if(userIsAlreadyFriend){
                    TextView error = (TextView) findViewById(R.id.friends_page_error_textview);
                    error.setText("Error user is already friend");
                    userIsAlreadyFriend = false;
                    userDoesNotExist = true;
                    return;
                }
                checkIfUserExists(friendToBeAdded);
                if(userDoesNotExist){
                    TextView error = (TextView) findViewById(R.id.friends_page_error_textview);
                    error.setText("Error user does not exist");
                    userIsAlreadyFriend = false;
                    userDoesNotExist = true;
                    return;
                }

                AddFriend(friendToBeAdded);
                TextView error = (TextView) findViewById(R.id.friends_page_error_textview);
                error.setText("Successfully added " + friendToBeAdded);
            }
        });
        final Button removeFriendButton = (Button) findViewById(R.id.friends_page_deletefriend_button);
        removeFriendButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                TextInputEditText addFriendEditText = (TextInputEditText) findViewById(R.id.friends_page_addfriendtextInput);
                String friendToBeDeleted = addFriendButton.getText().toString();
                checkIfAlreadyFriend(friendToBeDeleted);
                if(!userIsAlreadyFriend){
                    TextView error = (TextView) findViewById(R.id.friends_page_error_textview);
                    error.setText("Error user is not in friends list");
                    userIsAlreadyFriend = false;
                    userDoesNotExist = true;
                    return;
                }
            }
        });
    }
    public void checkIfAlreadyFriend(final String username){
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String currentUserId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                String listOfFriends = dataSnapshot.child("users").child(currentUserId).child("friends").getValue(String.class).toString();
                String[] arrayOfFriendsIds = listOfFriends.split(" ");
                System.out.println("array:");

                System.out.println("list:");

                System.out.println(listOfFriends);

                String userNames ="";
                if (listOfFriends.length()>0) {
                    for (String itor : arrayOfFriendsIds) {
                        userNames = userNames + " " + dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString();
                        System.out.println("name: ");
                        System.out.println(itor);
                    }
                }
                if (userNames.contains(username)) {
                    userIsAlreadyFriend = true;
                    System.out.println("FRIEND ALREADY"); //debugging does not print on app
                } else {
                    userIsAlreadyFriend = false;
                    System.out.println("NOT YET FRIEND"); //debugging does not print on app
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);
    }
    public void checkIfUserExists(final String username){
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String listOfUsersIds = dataSnapshot.child("listOfUsers").getValue(String.class).toString();
                String [] arrayUserIds = listOfUsersIds.split(" ");
                String userNames ="";
                for (String itor: arrayUserIds){
                    userNames= userNames + " " + dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString();
                }
                System.out.println(listOfUsersIds);
                System.out.println(arrayUserIds);
                System.out.println(userNames);
                if (userNames.contains(username)) {
                    userDoesNotExist = false;
                    System.out.println("EXITS ALREADY");
                } else {
                    userDoesNotExist = true;
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);
    }
    public void AddFriend(final String friendToBeAdded){
        final DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String currentUserId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                String listOfFriendsIds = dataSnapshot.child("users").child(currentUserId).child("friends").getValue(String.class).toString();
                String idOfFriendToBeAdded="";
                String listOfAllUsersIds = dataSnapshot.child("listOfUsers").getValue(String.class).toString();
                String [] arrayOfAllUserIds = listOfAllUsersIds.split(" ");
                for (String itor: arrayOfAllUserIds){
                    if (dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString().equals(friendToBeAdded)){
                        idOfFriendToBeAdded = itor;
                    }
                }
                if (listOfFriendsIds.length()>0 ) {
                    if (!listOfFriendsIds.contains(idOfFriendToBeAdded)) {
                        String newListOfFriends = listOfFriendsIds + " " + idOfFriendToBeAdded;
                        database.child("users").child(currentUserId).child("friends").setValue(newListOfFriends);
                    }
                } else {
                    database.child("users").child(currentUserId).child("friends").setValue(idOfFriendToBeAdded);

                }

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);
    }
}