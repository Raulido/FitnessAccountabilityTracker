package com.example.raulp.loginsign_up.AccountActivity;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ArrayAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.Arrays;

import com.google.firebase.database.ValueEventListener;

public class CreateNewMatchActivity extends AppCompatActivity {
    String[] friends;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String currentUserId = FirebaseAuth.getInstance().getUid(); //to get current User ID

                String username = dataSnapshot.child("users").child(currentUserId).child("username").getValue(String.class);
                TextView usernameTextview = (TextView) findViewById(R.id.createnewmatch_username);
                usernameTextview.setText(username);


                String listOfFriendIds = dataSnapshot.child("users").child(currentUserId).child("friends").getValue(String.class).toString();
                String[] arrayOfFriendsIds = listOfFriendIds.split(" ");
                ArrayList<String> usernames = new ArrayList<String>();
                if (listOfFriendIds.length() > 0) {
                    for (String itor : arrayOfFriendsIds) {
                        usernames.add(dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString());
                        System.out.println("itor:" + itor);
                        System.out.println("friendsadd:" + dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString());
                    }
                }
                System.out.println("array of friend ids:" + Arrays.toString(arrayOfFriendsIds));
                System.out.println("listoffriendids:" + listOfFriendIds);

                friends = usernames.toArray(new String[usernames.size()]);
                System.out.println("friends in main array:" + Arrays.toString(friends));
                displayFriendsDropdown();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        database.addListenerForSingleValueEvent(changeListener);


        setContentView(R.layout.activity_createnewmatch);
        addListenerOnButton();
    }

    public void addListenerOnButton() {
        Button confirmbutton = (Button) findViewById(R.id.button7);
        confirmbutton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                TextInputEditText dateinput = (TextInputEditText) findViewById(R.id.createnewmatch_date);
                String date = dateinput.getText().toString();
                TextInputEditText timeinput = (TextInputEditText) findViewById(R.id.createnewmatch_time);
                String time = timeinput.getText().toString();
                TextInputEditText locationinput = (TextInputEditText) findViewById(R.id.createnewmatch_location);
                String location = locationinput.getText().toString();
                AddMatch(date+" "+time+" "+ location);
            }
        });
    }

    public void displayFriendsDropdown() {
        Spinner chooseFriendDropDown = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> adapter;
        System.out.println("friends before adapter:" + Arrays.toString(friends));
        adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, friends);
        chooseFriendDropDown.setAdapter(adapter);
    }
    public void AddMatch(final String match){
        final DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String currentUserId = FirebaseAuth.getInstance().getUid(); //to get current User ID
                String matches = dataSnapshot.child("users").child(currentUserId).child("upcoming_matches").getValue(String.class).toString();

                String currentName = dataSnapshot.child("users").child(currentUserId).child("username").getValue(String.class).toString();
                Spinner mySpinner=(Spinner) findViewById(R.id.spinner);
                String selectedfriend = mySpinner.getSelectedItem().toString();
                String newMatches = matches;
                if (!matches.contains(match)){
                    newMatches = matches+" FATMATCH: " + match + " with " + selectedfriend;
                }
                database.child("users").child(currentUserId).child("upcoming_matches").setValue(newMatches);
                TextView confirmed = (TextView) findViewById(R.id.textView16);
                confirmed.setText("Match confirmed: "+ match + " with " + selectedfriend);

                String idOfFriendToBeAdded="";
                String listOfAllUsersIds = dataSnapshot.child("listOfUsers").getValue(String.class).toString();
                String [] arrayOfAllUserIds = listOfAllUsersIds.split(" ");
                for (String itor: arrayOfAllUserIds){
                    if (dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString().equals(selectedfriend)){
                        idOfFriendToBeAdded = itor;
                    }
                }
                String matchesofFriend = dataSnapshot.child("users").child(idOfFriendToBeAdded).child("upcoming_matches").getValue(String.class).toString();
                String newMatchesOffriend = matchesofFriend;
                if (!matchesofFriend.contains(match)){
                    newMatches = matches+" FATMATCH: " + match + " with " + currentName;
                }
                database.child("users").child(idOfFriendToBeAdded).child("upcoming_matches").setValue(newMatches);


                try
                {
                    Thread.sleep(3000);
                }
                catch(InterruptedException ex)
                {
                    Thread.currentThread().interrupt();
                }
                Intent intent = new Intent(CreateNewMatchActivity.this, HomePageActivity.class);
                startActivity(intent);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        database.addListenerForSingleValueEvent(changeListener);

    }

}


