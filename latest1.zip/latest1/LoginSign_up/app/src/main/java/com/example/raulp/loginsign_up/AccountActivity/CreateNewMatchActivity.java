package com.example.raulp.loginsign_up.AccountActivity;

import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ArrayAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.Arrays;

import com.google.firebase.database.ValueEventListener;

public class CreateNewMatchActivity extends AppCompatActivity {
    String[] friends;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String currentUserId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                String listOfFriendIds = dataSnapshot.child("users").child(currentUserId).child("friends").getValue(String.class).toString();
                String[] arrayOfFriendsIds = listOfFriendIds.split(" ");
                ArrayList <String> usernames = new ArrayList<String>();
                if (listOfFriendIds.length()>0) {
                    for (String itor : arrayOfFriendsIds) {
                        usernames.add(dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString());
                        System.out.println("itor:" +itor);
                        System.out.println("friendsadd:" + dataSnapshot.child("users").child(itor).child("username").getValue(String.class).toString());
                    }
                }
                System.out.println("array of friend ids:" + Arrays.toString(arrayOfFriendsIds));
                System.out.println("listoffriendids:" + listOfFriendIds);

                friends= usernames.toArray(new String[usernames.size()]);
                System.out.println("friends in main array:" + Arrays.toString(friends));
                displayFriendsDropdown();

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);


        setContentView(R.layout.activity_createnewmatch);
    }
    public void displayFriendsDropdown(){
        Spinner chooseFriendDropDown = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> adapter;
        System.out.println("friends before adapter:" + Arrays.toString(friends));
        adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, friends);
        chooseFriendDropDown.setAdapter(adapter);
    }

}
