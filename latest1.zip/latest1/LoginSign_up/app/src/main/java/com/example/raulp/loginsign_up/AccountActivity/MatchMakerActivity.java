package com.example.raulp.loginsign_up.AccountActivity;

import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;

public class MatchMakerActivity extends AppCompatActivity {
    ImageButton createNewMatchButton;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matchmaker);
        addListenerOnButton();
        final DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String currentUserId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
                String username = dataSnapshot.child("users").child(currentUserId).child("username").getValue(String.class);
                TextView usernameTextview = (TextView) findViewById(R.id.matchmaker_username);
                usernameTextview.setText(username);




                String upcomingMatchesString = dataSnapshot.child("users").child(currentUserId).child("upcoming_matches").getValue(String.class).toString();
                String[] upcomingMatchesArray = upcomingMatchesString.split("FATMATCH:");


                System.out.println(upcomingMatchesArray);

                String UpcomingMatches ="";
                if (upcomingMatchesString.length()>0) {
                    for (String itor : upcomingMatchesArray) {
                        UpcomingMatches = UpcomingMatches + "\n\n"+itor;
                        System.out.println("name: ");
                        System.out.println(itor);
                    }
                }
                TextView upcomingmatches = (TextView) findViewById(R.id.matchmaker_upcomingmatches);
                upcomingmatches.setText(UpcomingMatches);





            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addListenerForSingleValueEvent(changeListener);
    }

    public void addListenerOnButton() {
        createNewMatchButton= (ImageButton) findViewById(R.id.imageButton);
        createNewMatchButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(MatchMakerActivity.this, CreateNewMatchActivity.class);
                startActivity(intent);

            }
        });

    }

}
