package com.example.raulp.loginsign_up.AccountActivity;

import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ArrayAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;

import com.example.raulp.loginsign_up.R;

public class CreateNewMatchActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createnewmatch);
        Spinner chooseFriendDropDown = (Spinner) findViewById(R.id.spinner);
        String [] friends = new String[]{"Elliot kim", "Mike Lopez", "Armando Hoyos"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, friends);
        chooseFriendDropDown.setAdapter(adapter);
    }

}
