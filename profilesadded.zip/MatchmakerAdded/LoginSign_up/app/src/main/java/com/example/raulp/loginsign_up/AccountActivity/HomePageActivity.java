package com.example.raulp.loginsign_up.AccountActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.example.raulp.loginsign_up.R;
import com.google.firebase.database.*;
import com.google.firebase.auth.*;



public class HomePageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ////// code for reading from database
        final String userId  = FirebaseAuth.getInstance().getUid(); //to get current User ID
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        ValueEventListener changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("users").child(userId).child("username").getValue(String.class);  // Reading from users/UserID/username
                // Do stuff with the stuff we read
                TextView welcomeUserTextView = (TextView)findViewById(R.id.textView);
                welcomeUserTextView.setText("Welcome "+ name + "!");
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        database.addValueEventListener(changeListener);
        ////// end of code for reading from database


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        addListenerOnButton();


    }



    public void addListenerOnButton() {
        ImageButton imageButton_MatchMaker = (ImageButton) findViewById(R.id.imageButton2);
        imageButton_MatchMaker.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(HomePageActivity.this, MatchMakerActivity.class);
                startActivity(intent);
            }
        });
        ImageButton edit_profile = (ImageButton) findViewById(R.id.edit_profile_button);
        edit_profile.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(HomePageActivity.this, EditProfileActivity.class);
                startActivity(intent);
            }
        });
        ImageButton view_profile = (ImageButton) findViewById(R.id.home_page_view_profile_button);
        view_profile.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(HomePageActivity.this, ViewProfileActivity.class);
                startActivity(intent);
            }
        });

    }
}
