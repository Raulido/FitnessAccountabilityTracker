package com.example.raulp.loginsign_up.AccountActivity;

public class User {

    public String username;
    public String bio;
    public int experience;
    public int rank;
    public String last_workout;
    public int matches_won;


    public User() {
        this.username = "new user";
        this.bio= "about me";
        this.experience = 0;
        this.rank = 1;
        this.last_workout = "never";
        this.matches_won = 0;


    }
}